# Dataset

`demo_web_requests.csv` is a small demonstration dataset created so the repository can run end-to-end without the original project dataset.

For your actual academic project, replace it with the dataset you actually used and keep the same columns: `method`, `url`, `headers`, `payload`, `label`.
