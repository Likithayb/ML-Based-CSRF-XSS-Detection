from pathlib import Path
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from .features import extract_features

MODEL_DIR = Path("models")
MODEL_PATH = MODEL_DIR / "random_forest.joblib"


def train(csv_path: str):
    df = pd.read_csv(csv_path)
    X = extract_features(df)
    y = df["label"].astype(str).str.upper()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    model = RandomForestClassifier(n_estimators=250, random_state=42, class_weight="balanced")
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    metrics = {
        "accuracy": accuracy_score(y_test, pred),
        "report": classification_report(y_test, pred, output_dict=True, zero_division=0),
        "confusion_matrix": confusion_matrix(y_test, pred, labels=sorted(y.unique())).tolist(),
        "labels": sorted(y.unique()),
    }
    MODEL_DIR.mkdir(exist_ok=True)
    joblib.dump({"model": model, "feature_names": list(X.columns)}, MODEL_PATH)
    return metrics


def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Model not found. Run train_model.py first.")
    return joblib.load(MODEL_PATH)
