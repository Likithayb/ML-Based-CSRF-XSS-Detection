import re
import pandas as pd

SCRIPT_RE = re.compile(r"<\s*script\b|</\s*script\s*>|javascript\s*:", re.I)
EVENT_RE = re.compile(r"\bon\w+\s*=", re.I)
CSRF_RE = re.compile(r"csrf|xsrf|token|authenticity", re.I)
SUSPICIOUS_RE = re.compile(r"<|>|javascript:|onerror|onload|onclick|union\s+select|%3c|%3e", re.I)


def extract_features(df: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(index=df.index)
    method = df["method"].fillna("").astype(str).str.upper()
    url = df["url"].fillna("").astype(str)
    headers = df["headers"].fillna("").astype(str)
    payload = df["payload"].fillna("").astype(str)

    combined = url + " " + headers + " " + payload
    out["method_get"] = (method == "GET").astype(int)
    out["method_post"] = (method == "POST").astype(int)
    out["method_put"] = (method == "PUT").astype(int)
    out["method_delete"] = (method == "DELETE").astype(int)
    out["url_length"] = url.str.len()
    out["num_params"] = url.str.count(r"[?&][^=&]+=")
    out["num_special_chars"] = combined.str.count(r"[^A-Za-z0-9\s]")
    out["payload_length"] = payload.str.len()
    out["encoded_chars"] = combined.str.count(r"%[0-9A-Fa-f]{2}")
    out["has_script_tag"] = combined.str.contains(SCRIPT_RE).astype(int)
    out["has_event_handler"] = combined.str.contains(EVENT_RE).astype(int)
    out["has_csrf_token"] = combined.str.contains(CSRF_RE).astype(int)
    out["has_suspicious_pattern"] = combined.str.contains(SUSPICIOUS_RE).astype(int)
    out["has_origin"] = headers.str.contains(r"\borigin\s*:", case=False, regex=True).astype(int)
    out["has_referer"] = headers.str.contains(r"\breferer\s*:", case=False, regex=True).astype(int)
    out["has_cookie"] = headers.str.contains(r"\bcookie\s*:", case=False, regex=True).astype(int)
    return out
